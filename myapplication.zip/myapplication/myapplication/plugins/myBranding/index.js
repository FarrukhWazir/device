//Main module name must be defined in ngModules of the plugin manifest
angular.module('myapp.branding', [])
  .config(function () {
    
  });
