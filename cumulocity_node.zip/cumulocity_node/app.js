// MQTT dependency https://github.com/mqttjs/MQTT.js
const mqtt = require("mqtt");
var axios = require('axios');
var FormData = require('form-data');

var groups = get_tenant_groups();
groups.then(rest=>{
    console.log('GROUPS FROM CUMULOCITY')
    console.log(rest);
});

var devices = get_group_devices();
devices.then(rest=>{
    console.log('DEVICES FROM CUMULOCITY')
    console.log(rest);
    var configuration = [];
    var config_arr1 = rest['0'].configuration.split(',');
    var auth_token = '123456';
    var brand = 'dahua';
    var ip = config_arr1['2'].split('=')['1'];
    var username = config_arr1['3'].split('=')['1'];
    var password = config_arr1['4'].split('=')['1'];
    var api_url = "http://localhost/device_management/api_agent/";


    mqtt_connect_client(rest['0'].name,api_url,auth_token,brand,ip,username,password);
});

function mqtt_connect_client(clientId,api_url,device_auth_token,device_brand,device_ip,device_user,device_pass){

    var device_host = "http://"+device_ip;
    // client, user and device details
    const serverUrl   = "tcp://mqtt.cumulocity.com";
    var  device_name  = clientId;
    const tenant      = "t423154829";
    const username    = "dani@skais.com.my";
    const password    = "c8Y4ska!";

    var temperature   = 25;

    // connect the client to Cumulocity
    const client = mqtt.connect(serverUrl, {
        username: tenant + "/" + username,
        password: password,
        clientId: clientId
    });

    // once connected...
    client.on("connect", function () {
        // ...register a new device with restart operation
        client.publish("s/us", "100," + device_name + ",c8y_Serial", function() {

            console.log("Device "+clientId+" registered with restart operation support");

            //checking device status
                    var data = new FormData();
                    data.append("auth_token", device_auth_token);
                    data.append("brand", device_brand);
                    data.append("host", device_host);
                    data.append("user", device_user);
                    data.append("password", device_pass);

                    var config = {
                      method: 'post',
                      url: api_url+"get_time",
                      headers: { 
                        ...data.getHeaders()
                      },
                      data : data
                    };
                    axios(config)
                    .then(function (response) {
                       setTimeout(function() {
                            if(response.data != ''){

                                client.publish('s/us', '400,c8y_Check_Connection,"Connected status returned "', function() {
                                            });
                                client.publish("s/us", "501,c8y_Connection");
                                client.publish("s/us", "503,c8y_Connection");
                                console.log("Connected");
                                console.log(response.data);
                            }else{

                                    console.log('Disconnected');
                                }

                        }, 1000);
                    })
                    .catch(function (error) {
                      //console.log(error);
                      console.log('Disconnected');
                    });


                    setInterval(function() {
                        
                        
                        //checking device statusa
                        var data = new FormData();
                        data.append("auth_token", device_auth_token);
                        data.append("brand", device_brand);
                        data.append("host", device_host);
                        data.append("user", device_user);
                        data.append("password", device_pass);

                        var config = {
                          method: 'post',
                          url: api_url+"get_time",
                          headers: { 
                            ...data.getHeaders()
                          },
                          data : data
                        };
                        axios(config)
                        .then(function (response) {
                           setTimeout(function() {

                                if(response != ''){

                                    client.publish('s/us', '400,c8y_Check_Connection,"Connected status returned "', function() {
                                                });
                                    client.publish("s/us", "501,c8y_Connection");
                                    client.publish("s/us", "503,c8y_Connection");
                                    console.log("Connected");
                                }else{

                                    console.log('Disconnected');
                                }

                            }, 1000);
                        })
                        .catch(function (error) {
                          //console.log(error);
                          console.log('Disconnected');
                        });

                    }, 60000);
            // listen for operations
            client.subscribe("s/ds");

        });

    });



    // display all incoming messages
    client.on("message", function (topic, message) {
        console.log('Received operation "' + message + '"');
        if (message.toString().indexOf("510") == 0) {
            client.publish("s/us", "501,c8y_Restart");
            var data = new FormData();
            data.append("auth_token", device_auth_token);
            data.append("brand", device_brand);
            data.append("host", device_host);
            data.append("user", device_user);
            data.append("password", device_pass);

            var config = {
              method: 'post',
              url: api_url+"reboot",
              headers: { 
                ...data.getHeaders()
              },
              data : data
            };
            axios(config)
            .then(function (response) {
               setTimeout(function() {

                    client.publish("s/us", "503,c8y_Restart");
                    console.log("Restart Successfull");

                }, 1000);
            })
            .catch(function (error) {
              //console.log(error);
              console.log('error');
            });

        }
        //firmware payload = 515 
        else if (message.payloadString.indexOf("515") == 0) {
            
            client.publish("s/us", "501,c8y_Firmware");
            console.log('Initiating the upgrade process');
            var data_str  = message.payloadString.split(',');
            var upgrade_url = data_str[4];
            
            client.publish("s/us", "501,c8y_Firmware");
            console.log('Firmware File Download started'); 


            var data = [];
            data.append("auth_token", device_auth_token);
            data.append("brand", device_brand);
            data.append("host", device_host);
            data.append("user", device_user);
            data.append("password", device_pass);
            data.append("firmware_url", upgrade_url);
            data.append("tenant", tenant);
            data.append("auth", username+':'+password);

            var config = {
              method: 'post',
              url: api_url+"update_firmware_from_url",
              headers: { 
                            ...data.getHeaders()
                          },
              data : data
            };
            axios(config)
            .then(function (response) {
               setTimeout(function() {

                    client.publish("s/us", "503,c8y_Firmware");
                    console.log('FirmWare Updated  Successfully'); 

                }, 1000);
            })
            .catch(function (error) {
              //console.log(error);
              console.log('error');
            });

            
            
        }

         //software payload = 515 
        else if (message.payloadString.indexOf("516") == 0) {

            client.publish("s/us", "501,c8y_SoftwareList");
            console.log('Initiating the software installation process');
            var data_str  = message.payloadString.split(',');
            var software_url = data_str[4];

            client.publish("s/us", "501,c8y_SoftwareList");
            console.log('Software File Download started'); 


            var data = new FormData();
            data.append("auth_token", device_auth_token);
            data.append("brand", device_brand);
            data.append("host", device_host);
            data.append("user", device_user);
            data.append("password", device_pass);
            data.append("software_url", software_url);
            data.append("tenant", tenant);
            data.append("auth", username+':'+password);

            var config = {
              method: 'post',
              url: api_url+"installapp",
              headers: { 
                            ...data.getHeaders()
                          },
              data : data
            };
            axios(config)
            .then(function (response) {
               setTimeout(function() {

                    client.publish("s/us", "503,c8y_SoftwareList");
                    console.log('Software installed  Successfully'); 
                    console.log('API response =>'+response); 

                }, 1000);
            })
            .catch(function (error) {
              //console.log(error);
              console.log('error');
            });


           
            
            
        }

        else if (message.payloadString.indexOf("511") == 0) {

            var data_str  = message.payloadString.split(',');
            var opt = data_str[2].replace('"','');
            if( opt == 'remove'  || opt == 'Remove' || opt == 'REMOVE'){

                var appName = data_str[3].replace('"','');
            
                client.publish("s/us", "501,c8y_Command");

                console.log('Software uninstall process starting'); 


                var data = new FormData();
                data.append("auth_token", device_auth_token);
                data.append("brand", device_brand);
                data.append("host", device_host);
                data.append("user", device_user);
                data.append("password", device_pass);
                data.append("appName", appName);

                var config = {
                  method: 'post',
                  url: api_url+"uninstallapp",
                  headers: { 
                            ...data.getHeaders()
                          },
                  data : data
                };
                axios(config)
                .then(function (response) {
                   setTimeout(function() {

                        client.publish("s/us", "503,c8y_Command");
                        console.log('Software uninstalled  Successfully'); 
                        console.log('API response =>'+response); 

                    }, 1000);
                })
                .catch(function (error) {
                  //console.log(error);
                  console.log('error');
                });

            }

            if( opt == 'start' || opt == 'stop'){

                var appName = data_str[3].replace('"','');
            
                client.publish("s/us", "501,c8y_Command");

                console.log('Software '+opt+' process started'); 


                var data = new FormData();
                data.append("auth_token", device_auth_token);
                data.append("brand", device_brand);
                data.append("host", device_host);
                data.append("user", device_user);
                data.append("password", device_pass);
                data.append("appName", appName);
                data.append("action", opt);

                var config = {
                  method: 'post',
                  url: api_url+"start_stop_app",
                  headers: { 
                            ...data.getHeaders()
                          },
                  data : data
                };
                axios(config)
                .then(function (response) {
                   setTimeout(function() {

                        client.publish("s/us", "503,c8y_Command");
                        console.log('API response =>'+response); 

                    }, 1000);
                })
                .catch(function (error) {
                  //console.log(error);
                  console.log('error');
                }); 
            }


        }
    });



}





function get_tenant_groups(){
    return new Promise((resolve) => {
        try {
            var config = {
              method: 'get',
              url: 'https://ska.cumulocity.com/inventory/managedObjects?currentPage=1&withTotalPages=true&pageSize=20&query=$filter=((type eq \'c8y_DeviceGroup\') or (type eq \'c8y_DynamicGroup\'))$orderby=name&skipChildrenNames=true',
              
              headers: { 
                'Authorization': 'Basic ZGFuaUBza2Fpcy5jb20ubXk6YzhZNHNrYSE='
              }
            };
            axios(config)
            .then(response=>{
              if (response.status == 200) {
                if(response.data!=''){

                    var result_data = [];
                    var data_obj = response.data.managedObjects;
                    for (var i = data_obj.length - 1; i >= 0; i--) {
                         result_data.push({"id":data_obj[i].id,"name":data_obj[i].name});
                     } 
                    resolve(result_data);
                }else{
                  resolve(1); 
                }
              }else{
                  resolve(1); 
              }

            });
        }catch(error){
            resolve(error);
        }
    });
}

function get_group_devices(group_id){
    return new Promise((resolve) => {
        try {
            var config = {
              method: 'get',
              //url: 'https://ska.cumulocity.com/inventory/managedObjects?fragmentType=c8y_IsDevice&pageSize=10&skipChildrenNames=true&withTotalPages=true',
              url: 'https://ska.cumulocity.com/inventory/managedObjects?pageSize=100&q=&withGroups=true&withTotalPages=true',
              headers: { 
                'Authorization': 'Basic ZGFuaUBza2Fpcy5jb20ubXk6YzhZNHNrYSE='
              }
            };
            axios(config)
            .then(response=>{
              if (response.status == 200) {
                if(response.data!=''){

                    var result_data = [];
                    var data_obj = response.data.managedObjects;
                    for (var i = data_obj.length - 1; i >= 0; i--) {
                         result_data.push({"id":data_obj[i].id,"name":data_obj[i].name,"externalId":data_obj[i].c8y_Hardware.serialNumber,"configuration":data_obj[i].c8y_Configuration.config});
                     } 
                    resolve(result_data);
                }else{
                  resolve(1); 
                }
              }else{
                  resolve(1); 
              }

            });
        }catch(error){
            resolve(error);
        }
    });
}

