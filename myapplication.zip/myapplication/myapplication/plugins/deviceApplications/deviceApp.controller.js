(function() {
  'use strict';

  angular
    .module('myapp.deviceApp')
    .controller('deviceAppCtrl', deviceAppController);

  /* @ngInject */
  function deviceAppController($scope, $routeParams,c8yEvents,c8yAlarms,c8yBase, c8yRealtime, $http, c8yDevices, c8yAlert, c8yDeviceControl) {

    var deviceId = $routeParams.deviceId;
    var eventsChannel = '/events/' + deviceId;
    var SCOPE_ID = $scope.$id;

    function onload_events(){

      c8yEvents.list(
        _.assign(c8yBase.timeOrderFilter(), {
          type: 'c8y_EntranceEvent',
          source: $routeParams.deviceId,
          dateFrom:'1970-01-01',
          dateTo:new Date().toISOString().replace('Z','+08:00')
        })
      ).then(function (events) {
        $scope.events = events;
      });

    }
    function startRealtime() {
      c8yRealtime.start(SCOPE_ID, eventsChannel);
    }

    function setUpListeners() {
      c8yRealtime.addListener(SCOPE_ID, eventsChannel, 'CREATE', onCreateEvent);
      c8yRealtime.addListener(SCOPE_ID, eventsChannel, 'DELETE', onDeleteEvent);
    }

    function stopRealtime() {
      c8yRealtime.stop(SCOPE_ID, eventsChannel);
    }

    function onCreateEvent(action, eventObject) {
      if(eventObject.type === "c8y_EntranceEvent" ){

        $scope.events.unshift(eventObject);
        var dateTo = new Date();
        var dateFrom = new Date(dateTo.getTime() - (5*60*1000));
        c8yEvents.list(
          _.assign(c8yBase.timeOrderFilter(), {
            type: 'c8y_EntranceEvent',
            source: $routeParams.deviceId,
            dateFrom:dateFrom.toISOString().replace('Z','+08:00'),
            dateTo:dateTo.toISOString().replace('Z','+08:00'),
            person_TCKN:eventObject.person_TCKN
          })
        ).then(function (events) {
          // if(events.length > 1){
          //   c8yAlert.warning('Duplicate Entry : ' + eventObject.text + '.' );
          // }

          for (var i = events.length - 1; i >= 0; i--) {
            if(events[i].person_TCKN === eventObject.person_TCKN &&  events[i].id !== eventObject.id){


              c8yAlert.warning('Duplicate Entry : ' + eventObject.text + '.' );
              eventObject.isduplicate = 1;
              c8yAlarms.save({
                type: 'Custom alarm',
                severity: c8yAlarms.severity.CRITICAL,
                status: c8yAlarms.status.ACTIVE,
                text: 'Duplicate Entry:'+events[i].text,
                time: moment().format(c8yBase.dateFormat),
                source: {
                  id: $routeParams.deviceId
                }
              });
              c8yEvents.save({
                id: eventObject.id,
                isduplicate: 1

              });
            }
          }
          setTimeout(function() {
            $scope.events.unshift(eventObject);
          }, 3000);
          
        });

      }
    }

    function onDeleteEvent(action, eventObjectId) {
      _.remove($scope.events, function (evt) {
        return evt.id === eventObjectId;
      });

      c8yAlert.info('Event with id ' + eventObjectId + ' has been deleted.' );
    }

    $scope.events = [];
    $scope.$on('$destroy', stopRealtime);
    onload_events();
    setUpListeners();
    startRealtime();
  }

}());
