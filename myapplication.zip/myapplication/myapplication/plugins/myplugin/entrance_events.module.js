(function () {
  'use strict';

  angular.module('myapp.entrance_events', []);
}());
