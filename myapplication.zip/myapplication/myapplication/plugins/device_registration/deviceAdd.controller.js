(function() {
  'use strict';

  angular
    .module('myapp.deviceAdd')
    .controller('deviceAddCtrl', DeviceAddController);

  /* @ngInject */
  function DeviceAddController($scope, $routeParams, c8yDevices, c8yAlert, $http) {

    
    function get_groups (){
      //https://ska.cumulocity.com/inventory/managedObjects?fragmentType=c8y_IsDeviceGroup&pageSize=10000&withTotalPages=true
      $http.get("https://ska.cumulocity.com/inventory/managedObjects?fragmentType=c8y_IsDeviceGroup&pageSize=10000&withTotalPages=true")
      .then(function(response) {
        var deviceObjects = response.data.managedObjects;
        
        for (var i = deviceObjects.length - 1; i >= 0; i--) {
          
          $scope.groups.push( {
            id: deviceObjects[i].id,
            name: deviceObjects[i].name,

          }); 

        }
        
        
      },
      function myError(response) {
        
      });

    } 
    function load(){

        var device;
        $scope.device = {};
    }
    function save(device) {

      device.device_password = btoa(device.device_password);
    	var data = ' { "name": "'+device.device_serialNumber+'","c8y_Hardware": {   "serialNumber": "'+device.device_serialNumber+'"}, "type": "c8y_Device","c8y_SupportedOperations": [ "c8y_Restart", "c8y_Configuration", "c8y_Software", "c8y_Firmware","c8y_SoftwareList","c8y_Command" ], "c8y_IsDevice": {},"c8y_RequiredAvailability": { "responseInterval": 2 },"c8y_Configuration": {"config": "ip='+ device.device_host +',username='+ device.device_user +',password='+ device.device_password +'"} }';
        
        var xhr = new XMLHttpRequest();
        xhr.withCredentials = true;

        xhr.addEventListener("readystatechange", function() {
            var headers = xhr.getResponseHeader("Location");
            if(headers !=='' && headers !=='null' ){
              device.location = headers;
              var header_link = device.location.split("/");
              device.device_id = header_link[header_link.length -1];
              update_external_id(device.device_id,device.device_serialNumber);
              add_device_parent(device.location,device.device_id,device.device_group);
              add_device_group(device.device_id,device.device_group);
              
            }

        });

        xhr.open("POST", "https://ska.cumulocity.com/inventory/managedObjects");
        xhr.setRequestHeader("Authorization", "Basic ZGFuaUBza2Fpcy5jb20ubXk6YzhZNHNrYSE=");
        xhr.setRequestHeader("Content-Type", "application/json");

        xhr.send(data);

    }

    function update_external_id(device_id,external_id){

      var data = '{"externalId" : "'+ external_id +'", "type" : "c8y_Serial"}';
      var xhr2 = new XMLHttpRequest();
      xhr2.withCredentials = true;

      xhr2.addEventListener("readystatechange", function() {

      });

      xhr2.open("POST", "https://ska.cumulocity.com/identity/globalIds/"+ device_id +"/externalIds");
      xhr2.setRequestHeader("Authorization", "Basic ZGFuaUBza2Fpcy5jb20ubXk6YzhZNHNrYSE=");
      xhr2.setRequestHeader("Content-Type", "application/json");

      xhr2.send(data);

    }

    function add_device_group(device_id,device_group){

      var data = '{ "managedObject": {"id":"'+ device_id +'"} }';
          var xhr3 = new XMLHttpRequest();
          xhr3.withCredentials = true;

          xhr3.addEventListener("readystatechange", function() {
          window.location.href = "#/device";
          });

          xhr3.open("POST", "https://ska.cumulocity.com/inventory/managedObjects/"+device_group+"/childAssets");
          xhr3.setRequestHeader("Authorization", "Basic ZGFuaUBza2Fpcy5jb20ubXk6YzhZNHNrYSE=");
          xhr3.setRequestHeader("Content-Type", "application/json");

          xhr3.send(data);
    }

    function add_device_parent(device_location,device_id,edge_client_id){

      	$http.get("https://ska.cumulocity.com/inventory/managedObjects?pageSize=1&q=$filter=(c8y_Hardware.serialNumber eq '" + edge_client_id + "')&skipChildrenNames=false")
      	.then(function(response) {
          
	        var parent_id = response.data.managedObjects[0].id;
          //add_device_group(parent_id,edge_client_id);
	        if(parent_id !== device_id){

	          var data = '{"managedObject" : { "self" : "'+device_location+'" }}';
	          var xhr3 = new XMLHttpRequest();
	          xhr3.withCredentials = true;

	          xhr3.addEventListener("readystatechange", function() {
	          });

	          xhr3.open("POST", "https://ska.cumulocity.com/inventory/managedObjects/"+parent_id+"/childDevices");
	          xhr3.setRequestHeader("Authorization", "Basic ZGFuaUBza2Fpcy5jb20ubXk6YzhZNHNrYSE=");
	          xhr3.setRequestHeader("Content-Type", "application/json");

	          xhr3.send(data);
	        }


      	});

      
    }
    
    $scope.device = {};
    $scope.save = save;
    $scope.update_external_id = update_external_id;
    $scope.add_device_group = add_device_group;
    $scope.add_device_parent = add_device_parent;
    $scope.groups = [];
    $scope.isparent = "";
    get_groups();
    load();

  }

}());
