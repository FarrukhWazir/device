(function() {
  'use strict';

  angular
    .module('myapp.deviceApp')
    .controller('deviceAppCtrl', DeviceAppController);

  

  /* @ngInject */
  function DeviceAppController($scope, $routeParams, c8yDevices, c8yAlert, $http) {

    // var vm = this;
    
    // vm.columns = ["SYSTEM ID","NAME","MODEL","SERIAL NUMBER","GROUP","ACTIONS"];
    // vm.rows = get_device();

    function get_device (){

      $http.get("https://ska.cumulocity.com/inventory/managedObjects?currentPage=1&withTotalPages=true&pageSize=20&query=$filter=((type eq 'c8y_Device') or (type eq 'c8y_Serial'))$orderby=name&skipChildrenNames=false")
      .then(function(response) {
        var deviceObjects = response.data.managedObjects;
        
        for (var i = deviceObjects.length - 1; i >= 0; i--) {
          
          $scope.rows.push( {
            id: deviceObjects[i].id,
            name: deviceObjects[i].name,
            model: deviceObjects[i].name,
            serialno: deviceObjects[i].name,
            action_id: deviceObjects[i].id

          }); 

        }
        
        
      },
      function myError(response) {
        
      });

    } 

    $scope.rows = [];
    $scope.columns = ["SYSTEM ID","NAME","MODEL","SERIAL NUMBER","GROUP","ACTIONS"];
    get_device();
    

  }

}());
