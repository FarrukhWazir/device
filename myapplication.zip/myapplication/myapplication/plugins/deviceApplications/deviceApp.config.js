(function() {
  'use strict';

  angular
    .module('myapp.deviceApp')
    .config(configure);

  /* @ngInject */
  function configure(c8yViewsProvider) {
    c8yViewsProvider.when('/device/:deviceId', {
      name: 'Entrance Events',
      icon: 'floppy-o',
      priority: 1000,
      templateUrl: ':::PLUGIN_PATH:::/views/deviceApp.html',
      controller: 'deviceAppCtrl'
    });
  }

}());
